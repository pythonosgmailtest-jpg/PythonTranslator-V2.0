import customtkinter as ctk
import urllib.request
import urllib.parse
import json

# Set appearance theme
ctk.set_appearance_mode("Dark")
ctk.set_default_color_theme("blue")

class NativeTranslator(ctk.CTk):
    def __init__(self):
        super().__init__()

        # Window Configuration & Start with 0 alpha for smooth fade-in
        self.title("Chat Translator Pro")
        self.geometry("500x670")
        self.resizable(False, False)
        self.attributes("-alpha", 0.0)  # Start invisible for animation
        self.fade_in(0.0)

        # Always on Top state
        self.is_pinned = False
        self.attributes("-topmost", False)

        # Supported Languages (Updated with Korean)
        self.languages = {
            "English": "en",
            "Spanish": "es",
            "Turkish": "tr",
            "Italian": "it",
            "French": "fr",
            "German": "de",
            "Russian": "ru",
            "Ukrainian": "uk",
            "Greek": "el",
            "Vietnamese": "vi",
            "Indonesian": "id",
            "Japanese": "ja",
            "Korean": "ko",
            "Indian": "hi",
            "Pakistani": "ur",
            "Chinese": "zh-CN",
            "Arabic": "ar"
        }

        self.setup_ui()

    def fade_in(self, alpha):
        """Smooth window fade-in animation on startup"""
        alpha += 0.06
        if alpha <= 1.0:
            self.attributes("-alpha", alpha)
            self.after(15, lambda: self.fade_in(alpha))
        else:
            self.attributes("-alpha", 1.0)

    def setup_ui(self):
        # Custom Theme Colors (Obsidian & Indigo Palette)
        self.bg_color = "#111318"
        self.card_color = "#1b1f2b"
        self.input_color = "#222736"
        self.accent_color = "#4f46e5"      # Deep Indigo
        self.accent_hover = "#6366f1"
        self.success_color = "#059669"     # Emerald Green
        self.success_hover = "#10b981"

        self.configure(fg_color=self.bg_color)

        # Header Frame
        header_frame = ctk.CTkFrame(self, fg_color="transparent")
        header_frame.pack(fill="x", padx=20, pady=(18, 6))

        title_label = ctk.CTkLabel(
            header_frame, 
            text="✨ Chat Translator", 
            font=ctk.CTkFont(family="Segoe UI", size=17, weight="bold"),
            text_color="#f3f4f6"
        )
        title_label.pack(side="left")

        self.btn_pin = ctk.CTkButton(
            header_frame,
            text="📌 Pin: Off",
            width=90,
            height=32,
            font=ctk.CTkFont(family="Segoe UI", size=11, weight="bold"),
            fg_color="#27272a",
            hover_color="#3f3f46",
            text_color="#d1d5db",
            corner_radius=8,
            command=self.toggle_pin
        )
        self.btn_pin.pack(side="right")

        # TAB VIEW (Modern Rounded Tab System)
        self.tabview = ctk.CTkTabview(
            self, 
            width=460, 
            height=540, 
            corner_radius=14,
            fg_color=self.card_color,
            segmented_button_fg_color="#12141a",
            segmented_button_selected_color=self.accent_color,
            segmented_button_selected_hover_color=self.accent_hover,
            segmented_button_unselected_color="#1b1f2b",
            segmented_button_unselected_hover_color="#272b38"
        )
        self.tabview.pack(padx=20, pady=5, fill="both", expand=True)

        # Add Tabs
        self.tab_translate = self.tabview.add("Text Translate")
        self.tab_pronounce = self.tabview.add("Phonetic & Translate")

        self.build_translate_tab()
        self.build_pronounce_tab()

        # Status Bar
        self.status_label = ctk.CTkLabel(
            self, 
            text="Ready", 
            font=ctk.CTkFont(family="Segoe UI", size=11), 
            text_color="#9ca3af",
            anchor="w"
        )
        self.status_label.pack(fill="x", padx=25, pady=(0, 14))

    def build_translate_tab(self):
        container = ctk.CTkFrame(self.tab_translate, fg_color="transparent")
        container.pack(fill="both", expand=True, padx=10, pady=10)

        top_row = ctk.CTkFrame(container, fg_color="transparent")
        top_row.pack(fill="x", pady=(0, 6))

        lbl = ctk.CTkLabel(top_row, text="Input Text", font=ctk.CTkFont(family="Segoe UI", size=12, weight="bold"), text_color="#d1d5db")
        lbl.pack(side="left")

        self.lang_target = ctk.StringVar(value="Spanish")
        menu_lang = ctk.CTkOptionMenu(
            top_row, 
            variable=self.lang_target, 
            values=list(self.languages.keys()),
            width=140,
            height=32,
            corner_radius=8,
            fg_color="#272b38",
            button_color="#374151",
            button_hover_color="#4b5563"
        )
        menu_lang.pack(side="right")

        self.input_tr = ctk.CTkEntry(
            container, 
            placeholder_text="Type or paste text here...", 
            font=ctk.CTkFont(family="Segoe UI", size=13),
            height=42,
            corner_radius=8,
            fg_color=self.input_color,
            border_color="#374151"
        )
        self.input_tr.pack(fill="x", pady=(0, 10))
        self.input_tr.bind("<Return>", lambda event: self.get_translation())

        btn_translate = ctk.CTkButton(
            container, 
            text="Translate Text", 
            font=ctk.CTkFont(family="Segoe UI", size=13, weight="bold"),
            height=40,
            corner_radius=8,
            fg_color=self.accent_color,
            hover_color=self.accent_hover,
            command=self.get_translation
        )
        btn_translate.pack(fill="x", pady=(0, 15))

        lbl_out = ctk.CTkLabel(container, text="Translation Result", font=ctk.CTkFont(family="Segoe UI", size=12, weight="bold"), text_color="#d1d5db")
        lbl_out.pack(anchor="w", pady=(0, 6))

        self.box_tr = ctk.CTkTextbox(
            container, 
            height=110, 
            font=ctk.CTkFont(family="Segoe UI", size=13),
            corner_radius=8,
            fg_color=self.input_color,
            border_color="#374151"
        )
        self.box_tr.pack(fill="x", pady=(0, 15))

        bottom = ctk.CTkFrame(container, fg_color="transparent")
        bottom.pack(fill="x")

        btn_clear = ctk.CTkButton(
            bottom, 
            text="Clear", 
            width=90,
            height=34,
            fg_color="#272b38",
            hover_color="#374151",
            text_color="#d1d5db",
            corner_radius=8,
            command=lambda: self.clear_fields(self.input_tr, self.box_tr)
        )
        btn_clear.pack(side="right", padx=(10, 0))

        btn_copy = ctk.CTkButton(
            bottom, 
            text="Copy Result", 
            width=120,
            height=34,
            fg_color=self.success_color,
            hover_color=self.success_hover,
            corner_radius=8,
            command=lambda: self.copy_text(self.box_tr.get("1.0", "end-1c"))
        )
        btn_copy.pack(side="right")

    def build_pronounce_tab(self):
        container = ctk.CTkFrame(self.tab_pronounce, fg_color="transparent")
        container.pack(fill="both", expand=True, padx=10, pady=10)

        top_row = ctk.CTkFrame(container, fg_color="transparent")
        top_row.pack(fill="x", pady=(0, 6))

        lbl = ctk.CTkLabel(top_row, text="Input Text", font=ctk.CTkFont(family="Segoe UI", size=12, weight="bold"), text_color="#d1d5db")
        lbl.pack(side="left")

        self.lang_target_ph = ctk.StringVar(value="Turkish")
        menu_lang = ctk.CTkOptionMenu(
            top_row, 
            variable=self.lang_target_ph, 
            values=list(self.languages.keys()),
            width=140,
            height=32,
            corner_radius=8,
            fg_color="#272b38",
            button_color="#374151",
            button_hover_color="#4b5563"
        )
        menu_lang.pack(side="right")

        self.input_ph = ctk.CTkEntry(
            container, 
            placeholder_text="Type foreign text (e.g., Korean, Japanese)...", 
            font=ctk.CTkFont(family="Segoe UI", size=13),
            height=38,
            corner_radius=8,
            fg_color=self.input_color,
            border_color="#374151"
        )
        self.input_ph.pack(fill="x", pady=(0, 8))
        self.input_ph.bind("<Return>", lambda event: self.get_pronunciation_and_translation())

        btn_translate = ctk.CTkButton(
            container, 
            text="Translate & Phoneticize", 
            font=ctk.CTkFont(family="Segoe UI", size=12, weight="bold"),
            height=38,
            corner_radius=8,
            fg_color=self.accent_color,
            hover_color=self.accent_hover,
            command=self.get_pronunciation_and_translation
        )
        btn_translate.pack(fill="x", pady=(0, 10))

        # Phonetic Output
        lbl_ph = ctk.CTkLabel(container, text="Phonetic (Latin Pronunciation)", font=ctk.CTkFont(family="Segoe UI", size=11, weight="bold"), text_color="#38bdf8")
        lbl_ph.pack(anchor="w", pady=(0, 2))

        self.box_ph = ctk.CTkTextbox(
            container, 
            height=52, 
            font=ctk.CTkFont(family="Segoe UI", size=12, slant="italic"),
            corner_radius=8,
            fg_color=self.input_color,
            border_color="#374151"
        )
        self.box_ph.pack(fill="x", pady=(0, 8))

        # Target Language Meaning Output
        lbl_tr = ctk.CTkLabel(container, text="Meaning in Target Language", font=ctk.CTkFont(family="Segoe UI", size=11, weight="bold"), text_color="#34d399")
        lbl_tr.pack(anchor="w", pady=(0, 2))

        self.box_ph_tr = ctk.CTkTextbox(
            container, 
            height=52, 
            font=ctk.CTkFont(family="Segoe UI", size=12),
            corner_radius=8,
            fg_color=self.input_color,
            border_color="#374151"
        )
        self.box_ph_tr.pack(fill="x", pady=(0, 10))

        bottom = ctk.CTkFrame(container, fg_color="transparent")
        bottom.pack(fill="x")

        btn_clear = ctk.CTkButton(
            bottom, 
            text="Clear", 
            width=70,
            height=32,
            fg_color="#272b38",
            hover_color="#374151",
            text_color="#d1d5db",
            corner_radius=8,
            command=lambda: self.clear_fields_multi(self.input_ph, self.box_ph, self.box_ph_tr)
        )
        btn_clear.pack(side="right", padx=(8, 0))

        btn_copy_tr = ctk.CTkButton(
            bottom, 
            text="Copy Translation", 
            width=115,
            height=32,
            fg_color=self.success_color,
            hover_color=self.success_hover,
            corner_radius=8,
            command=lambda: self.copy_text(self.box_ph_tr.get("1.0", "end-1c"))
        )
        btn_copy_tr.pack(side="right", padx=(8, 0))

        btn_copy_ph = ctk.CTkButton(
            bottom, 
            text="Copy Phonetic", 
            width=100,
            height=32,
            fg_color="#0284c7",
            hover_color="#0ea5e9",
            corner_radius=8,
            command=lambda: self.copy_text(self.box_ph.get("1.0", "end-1c"))
        )
        btn_copy_ph.pack(side="right")

    def toggle_pin(self):
        self.is_pinned = not self.is_pinned
        self.attributes("-topmost", self.is_pinned)
        if self.is_pinned:
            self.btn_pin.configure(text="📌 Pin: On", fg_color=self.success_color, hover_color=self.success_hover)
            self.show_status("Always on Top Enabled", self.success_hover)
        else:
            self.btn_pin.configure(text="📌 Pin: Off", fg_color="#27272a", hover_color="#3f3f46")
            self.show_status("Always on Top Disabled", "#9ca3af")

    def animate_status_loading(self, step=0):
        """Dynamic dot animation for status bar during translation"""
        if getattr(self, "is_translating", False):
            dots = "." * ((step % 3) + 1)
            self.status_label.configure(text=f"Translating{dots}", text_color="#38bdf8")
            self.after(400, lambda: self.animate_status_loading(step + 1))

    def get_pronunciation_and_translation(self):
        text = self.input_ph.get().strip()
        target_code = self.languages.get(self.lang_target_ph.get(), "tr")
        
        if text:
            self.is_translating = True
            self.animate_status_loading()
            self.update()

            try:
                encoded_text = urllib.parse.quote(text, encoding='utf-8')
                url = f"https://translate.googleapis.com/translate_a/single?client=gtx&sl=auto&tl={target_code}&dt=t&dt=rm&q={encoded_text}"
                req = urllib.request.Request(url, headers={'User-Agent': 'Mozilla/5.0'})
                
                with urllib.request.urlopen(req) as response:
                    data = json.loads(response.read().decode('utf-8'))
                    
                    translated_parts = [segment[0] for segment in data[0] if segment[0] is not None]
                    translated_text = "".join(translated_parts)

                    phonetic_text = ""
                    if len(data) > 0 and len(data[0]) > 0:
                        for item in data[0]:
                            if len(item) >= 3 and item[2] is not None:
                                phonetic_text = item[2]
                            elif len(item) >= 4 and item[3] is not None:
                                phonetic_text = item[3]

                self.box_ph.delete("1.0", "end")
                res_ph = phonetic_text if phonetic_text else text
                self.box_ph.insert("1.0", res_ph)

                self.box_ph_tr.delete("1.0", "end")
                self.box_ph_tr.insert("1.0", translated_text)

                self.is_translating = False
                self.show_status("Translated successfully!", self.success_hover)
            except Exception as e:
                self.is_translating = False
                self.show_status("Translation error occurred!", "#ef4444")

    def get_translation(self):
        text = self.input_tr.get().strip()
        target_code = self.languages.get(self.lang_target.get(), "es")
        if text:
            self.is_translating = True
            self.animate_status_loading()
            self.update()

            try:
                encoded_text = urllib.parse.quote(text, encoding='utf-8')
                url = f"https://translate.googleapis.com/translate_a/single?client=gtx&sl=auto&tl={target_code}&dt=t&q={encoded_text}"
                req = urllib.request.Request(url, headers={'User-Agent': 'Mozilla/5.0'})
                
                with urllib.request.urlopen(req) as response:
                    data = json.loads(response.read().decode('utf-8'))
                    translated_parts = [segment[0] for segment in data[0] if segment[0] is not None]
                    translated_text = "".join(translated_parts)

                self.box_tr.delete("1.0", "end")
                self.box_tr.insert("1.0", translated_text)
                
                self.is_translating = False
                self.show_status("Translated successfully!", self.success_hover)
            except Exception as e:
                self.is_translating = False
                self.show_status("Translation error occurred!", "#ef4444")

    def copy_text(self, text):
        text = text.strip()
        if text:
            self.clipboard_clear()
            self.clipboard_append(text)
            self.show_status("Copied to clipboard!", self.success_hover)

    def clear_fields(self, entry_widget, text_widget):
        entry_widget.delete(0, "end")
        text_widget.delete("1.0", "end")
        self.show_status("Cleared", "#9ca3af")

    def clear_fields_multi(self, entry_widget, text_widget1, text_widget2):
        entry_widget.delete(0, "end")
        text_widget1.delete("1.0", "end")
        text_widget2.delete("1.0", "end")
        self.show_status("Cleared", "#9ca3af")

    def show_status(self, message, color):
        self.status_label.configure(text=message, text_color=color)

if __name__ == "__main__":
    app = NativeTranslator()
    app.mainloop()