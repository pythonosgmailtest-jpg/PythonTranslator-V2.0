Thanks for downloading !.

-------------------------------
THIS IS THE NEW VERSION OF THE OLD PYTHON TRANSLATER.
NEW FEATURES = Added more languages,New UI design
Version 2.0 is here !!
Now the translate works better and its simpler,also the UI is better now so you dont get confused.
--------------------------------------------------------------------------------------------------------------
                                      ADDED LANGUAGES
----------------
1) Ukrainian   
2) Greek
3) Vietnamese
4) Indonesian
5) Japanese
6) Korean
7) Indian
8) Pakistani
---------------
These all of the new updates thank you all for downloading Python Translator V2.0

